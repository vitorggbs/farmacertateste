<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function exigirLogin($cargoNecessario = null)
{
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: /farmacerta-erp/index.php');
        exit;
    }

    if ($cargoNecessario != null) {
        if ($_SESSION['cargo'] != $cargoNecessario) {
            header('Location: /farmacerta-erp/index.php?erro=acesso');
            exit;
        }
    }
}

