<?php

session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/../gerente/conexaoDB.php';
require_once __DIR__ . '/../cabecalho.php';

exigirLogin('balconista');

$usuarioId = (int) $_SESSION['usuario_id'];

$sql = "SELECT COUNT(*) AS vendas,
        COALESCE(SUM(valor_total), 0) AS total
        FROM vendas
        WHERE usuario_id = $usuarioId
        AND DATE(data_venda) = CURDATE()";

$resultado = mysqli_query($conexao, $sql);
$res = mysqli_fetch_assoc($resultado);
?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Balconista</title>
        <link rel="stylesheet" href="../style.css">
    </head>
    <body>
        <?php cabecalho('FarmaCerta - Balconista','balconista','inicio'); ?>
        <main class="container">
            <div class="card">
                <h2>RESUMO DO SEU DIA</h2>
                <div class="painel-inicio">
                    <div class="bloco">
                        <h3>
                            <?=$res['vendas']?>
                        </h3>
                        <p>Vendas realizadas</p>
                    </div>
                    <div class="bloco">
                        <h3>R$ <?=number_format($res['total'],2,',','.')?>
                        </h3>
                        <p>Total vendido</p>
                    </div>
                </div>
                <a class="botao" href="produtosbalconista.php">INICIAR VENDA</a>
            </div>
        </main>
    </body>
</html>
