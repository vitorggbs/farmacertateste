<?php

session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/../gerente/conexaoDB.php';
require_once __DIR__ . '/../cabecalho.php';

exigirLogin('balconista');

$usuarioId = (int) $_SESSION['usuario_id'];

$sql = "SELECT * FROM vendas
        WHERE usuario_id = $usuarioId
        ORDER BY id DESC";

$vendas = mysqli_query($conexao, $sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Histórico</title>
        <link rel="stylesheet" href="../style.css">
    </head>
    <body>
        <?php cabecalho('FarmaCerta - Balconista','balconista','historico'); ?>
        <main class="container">
            <section class="secao-branca">
                <h2>MEUS RECIBOS</h2>
                <table class="tabela">
                    <tr>
                        <th>Número</th>
                        <th>Data</th>
                        <th>Cliente</th>
                        <th>Pagamento</th>
                        <th>Valor</th>
                        <th>Ação</th>
                    </tr>
                    <?php while($v=mysqli_fetch_assoc($vendas)){ ?>
                        <tr>
                            <td>#<?=$v['id']?>
                            </td>
                            <td>
                                <?=date('d/m/Y H:i',strtotime($v['data_venda']))?>
                            </td>
                            <td>
                                <?=htmlspecialchars($v['cliente']?:'Não informado')?>
                            </td>
                            <td>
                                <?=$v['forma_pagamento']?>
                            </td>
                            <td>R$ <?=number_format($v['valor_total'],2,',','.')?>
                            </td>
                            <td>
                                <a class="acao" href="recibobalconista.php?id=<?=$v['id']?>">ABRIR</a>
                            </td>
                        </tr>
                    <?php } ?>
                </table>
            </section>
        </main>
    </body>
</html>
