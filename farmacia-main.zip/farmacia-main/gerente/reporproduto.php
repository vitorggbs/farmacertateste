<?php

session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/conexaoDB.php';

exigirLogin('gerente');

$produtoId = (int) $_POST['produto_id'];
$quantidade = (int) $_POST['quantidade'];

if ($produtoId < 1 || $quantidade < 1) {
    header('Location: produtosgerente.php?erro=reposicao');
    exit;
}

$sql = 'UPDATE produtos
        SET quantidade = quantidade + ?
        WHERE id = ?';

$stmt = mysqli_prepare($conexao, $sql);

mysqli_stmt_bind_param($stmt, 'ii', $quantidade, $produtoId);
mysqli_stmt_execute($stmt);

$usuarioId = (int) $_SESSION['usuario_id'];
$tipo = 'entrada';
$observacao = 'Reposição manual';

$sql = 'INSERT INTO movimentacoes_estoque
        (produto_id, usuario_id, tipo, quantidade, observacao)
        VALUES (?, ?, ?, ?, ?)';

$stmt = mysqli_prepare($conexao, $sql);

mysqli_stmt_bind_param(
    $stmt,
    'iisis',
    $produtoId,
    $usuarioId,
    $tipo,
    $quantidade,
    $observacao
);

mysqli_stmt_execute($stmt);

header('Location: produtosgerente.php?ok=reposto');
exit;

