<?php

$host = 'localhost';
$usuarioBanco = 'root';
$senhaBanco = 'usbw';
$nomeBanco = 'farmacia1';
$nomeFarmacia = 'Farmacia 1';
$conexao = mysqli_connect($host, $usuarioBanco, $senhaBanco, $nomeBanco);
if (!$conexao) { die('Erro ao conectar ao banco: ' . mysqli_connect_error()); }
mysqli_set_charset($conexao, 'utf8mb4');

