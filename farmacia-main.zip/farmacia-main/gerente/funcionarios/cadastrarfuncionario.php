<?php

session_start();

require_once __DIR__ . '/../../autenticacao.php';
require_once __DIR__ . '/../conexaoDB.php';

exigirLogin('gerente');

$nome = trim($_POST['nome']);
$cpf = preg_replace('/\D/', '', $_POST['cpf']);
$nascimento = $_POST['nascimento'];
$telefone = trim($_POST['telefone']);
$email = trim($_POST['email']);
$endereco = trim($_POST['endereco']);
$admissao = $_POST['admissao'];
$salario = (float) $_POST['salario'];
$horario = trim($_POST['horario']) . ' / 6x1';
$login = trim($_POST['login']);
$senha = trim($_POST['senha']);
$cargo = 'balconista';

if ($nascimento == '') {
    $nascimento = null;
}

if ($admissao == '') {
    $admissao = null;
}

$sql = 'INSERT INTO usuarios
        (nome, cpf, telefone, email, endereco, data_nascimento,
         data_admissao, salario, horario_escala, login, senha, cargo)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';

$stmt = mysqli_prepare($conexao, $sql);

mysqli_stmt_bind_param(
    $stmt,
    'sssssssdssss',
    $nome,
    $cpf,
    $telefone,
    $email,
    $endereco,
    $nascimento,
    $admissao,
    $salario,
    $horario,
    $login,
    $senha,
    $cargo
);

if (mysqli_stmt_execute($stmt)) {
    header('Location: funcionarios.php?ok=1');
    exit;
}

echo '<h2>CPF ou login já cadastrado.</h2>';
echo '<a href="funcionarios.php">Voltar</a>';
