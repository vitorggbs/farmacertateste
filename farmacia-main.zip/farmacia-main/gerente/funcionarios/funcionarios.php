<?php

session_start();

require_once __DIR__ . '/../../autenticacao.php';
require_once __DIR__ . '/../conexaoDB.php';

exigirLogin('gerente');

$sql = "SELECT * FROM usuarios
        WHERE cargo = 'balconista'
        ORDER BY nome";

$lista = mysqli_query($conexao, $sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Funcionários</title>
        <link rel="stylesheet" href="../../style.css">
    </head>
    <body>
        <header class="topo">
            <img src="../../assets/LOGO_1.png" width="200">
            <h1>Funcionários</h1>
            <div class="usuario-topo">
                <span>
                    <?=htmlspecialchars($_SESSION['usuario_nome'])?>
                </span>
                <a class="logout" href="../../logout.php">SAIR</a>
            </div>
        </header>
        <nav class="menu">
            <a href="../iniciogerente.php">INÍCIO</a>
            <a href="../produtosgerente.php">PRODUTOS</a>
            <a href="funcionarios.php">FUNCIONÁRIOS</a>
            <a href="../historicorecibogerente.php">RECIBOS</a>
        </nav>
        <main class="container">
            <div class="card" id="cadastrar">
                <h2>CADASTRAR BALCONISTA</h2>
                <?php if(isset($_GET['ok'])){?>
                    <p>Funcionário cadastrado!</p>
                <?php } ?>
                <form action="cadastrarfuncionario.php" method="POST">
                    <label>Nome completo</label>
                    <input name="nome" required>
                    <label>CPF</label>
                    <input name="cpf" maxlength="14" required>
                    <label>Nascimento</label>
                    <input type="date" name="nascimento">
                    <label>Telefone</label>
                    <input name="telefone">
                    <label>E-mail</label>
                    <input type="email" name="email">
                    <label>Endereço</label>
                    <input name="endereco">
                    <label>Admissão</label>
                    <input type="date" name="admissao">
                    <label>Salário</label>
                    <input type="number" step="0.01" name="salario">
                    <label>Horário</label>
                    <input name="horario" placeholder="08:00 às 17:00">
                    <label>Login</label>
                    <input name="login" required>
                    <label>Senha</label>
                    <input type="password" name="senha" minlength="6" required>
                    <button>CADASTRAR</button>
                </form>
            </div>
            <section class="secao-branca">
                <h2>BALCONISTAS</h2>
                <table class="tabela">
                    <tr>
                        <th>Nome</th>
                        <th>CPF</th>
                        <th>Contato</th>
                        <th>Login</th>
                        <th>Situação</th>
                        <th>Ação</th>
                    </tr>
                    <?php while($u=mysqli_fetch_assoc($lista)){ ?>
                        <tr>
                            <td>
                                <?=htmlspecialchars($u['nome'])?>
                            </td>
                            <td>
                                <?=htmlspecialchars($u['cpf'])?>
                            </td>
                            <td>
                                <?=htmlspecialchars(($u['telefone']?:'-').' / '.($u['email']?:'-'))?>
                            </td>
                            <td>
                                <?=htmlspecialchars($u['login'])?>
                            </td>
                            <td>
                                <?=$u['ativo']?'Ativo':'Inativo'?>
                            </td>
                            <td>
                                <form action="alterarstatus.php" method="POST">
                                    <input type="hidden" name="id" value="<?=$u['id']?>">
                                    <button>
                                        <?=$u['ativo']?'DESATIVAR':'ATIVAR'?>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                </table>
            </section>
        </main>
    </body>
</html>
