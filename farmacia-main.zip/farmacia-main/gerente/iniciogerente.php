<?php

session_start();

require_once __DIR__ . '/../autenticacao.php';
require_once __DIR__ . '/conexaoDB.php';
require_once __DIR__ . '/../cabecalho.php';

exigirLogin('gerente');

$sql = "SELECT COUNT(*) AS vendas,
        COALESCE(SUM(valor_total), 0) AS total,
        COALESCE(AVG(valor_total), 0) AS media
        FROM vendas
        WHERE DATE(data_venda) = CURDATE()";

$resultado = mysqli_query($conexao, $sql);
$res = mysqli_fetch_assoc($resultado);

$sql = "SELECT v.id, v.data_venda, v.forma_pagamento,
        v.valor_total, u.nome
        FROM vendas v
        INNER JOIN usuarios u ON u.id = v.usuario_id
        ORDER BY v.id DESC
        LIMIT 10";

$ultimas = mysqli_query($conexao, $sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Gerente</title>
        <link rel="stylesheet" href="../style.css">
    </head>
    <body>
        <?php cabecalho('FarmaCerta - Gerente','gerente','inicio'); ?>
        <main class="container">
            <div class="card">
                <h2>RESUMO DO DIA</h2>
                <div class="painel-inicio">
                    <div class="bloco">
                        <h3>R$ <?=number_format($res['total'],2,',','.')?>
                        </h3>
                        <p>Faturamento</p>
                    </div>
                    <div class="bloco">
                        <h3>
                            <?=$res['vendas']?>
                        </h3>
                        <p>Vendas</p>
                    </div>
                    <div class="bloco">
                        <h3>
                            <?=$res['vendas']?>
                        </h3>
                        <p>Recibos</p>
                    </div>
                    <div class="bloco">
                        <h3>R$ <?=number_format($res['media'],2,',','.')?>
                        </h3>
                        <p>Média por venda</p>
                    </div>
                </div>
            </div>
            <section class="secao-branca">
                <h2>ÚLTIMAS VENDAS</h2>
                <table class="tabela">
                    <tr>
                        <th>Data</th>
                        <th>Recibo</th>
                        <th>Balconista</th>
                        <th>Pagamento</th>
                        <th>Valor</th>
                    </tr>
                    <?php while($v=mysqli_fetch_assoc($ultimas)){ ?>
                        <tr>
                            <td>
                                <?=date('d/m/Y H:i',strtotime($v['data_venda']))?>
                            </td>
                            <td>#<?=$v['id']?>
                            </td>
                            <td>
                                <?=htmlspecialchars($v['nome'])?>
                            </td>
                            <td>
                                <?=htmlspecialchars($v['forma_pagamento'])?>
                            </td>
                            <td>R$ <?=number_format($v['valor_total'],2,',','.')?>
                            </td>
                        </tr>
                    <?php } ?>
                </table>
            </section>
        </main>
    </body>
</html>
