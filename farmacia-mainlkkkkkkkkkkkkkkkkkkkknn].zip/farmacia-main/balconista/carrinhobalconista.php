<?php

session_start();

require_once __DIR__ . '/../autenticacao.php';

exigirLogin('balconista');

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../gerente/conexaoDB.php';


/* =========================
   CARRINHO
   ========================= */

if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = array();
}

$farmaciaId = (int) $_SESSION['farmacia_id'];

$carrinho = $_SESSION['carrinho'];

$produtosCarrinho = array();

$total = 0;


/* =========================
   BUSCAR PRODUTOS DO CARRINHO
   ========================= */

foreach ($carrinho as $produto_id => $quantidade) {

    $produto_id = (int) $produto_id;
    $quantidade = (int) $quantidade;


    $stmt = mysqli_prepare(
        $conexao,
        "SELECT id, nome, preco, quantidade
         FROM produtos
         WHERE id = ?
         AND farmacia_id = ?"
    );


    mysqli_stmt_bind_param(
        $stmt,
        'ii',
        $produto_id,
        $farmaciaId
    );


    mysqli_stmt_execute($stmt);


    mysqli_stmt_bind_result(
        $stmt,
        $id,
        $nome,
        $preco,
        $estoque
    );


    if (mysqli_stmt_fetch($stmt)) {

        $subtotal =
            (float) $preco * $quantidade;

        $total += $subtotal;


        $produtosCarrinho[] = array(

            'id' => $id,

            'nome' => $nome,

            'preco' => $preco,

            'quantidade' => $quantidade,

            'estoque' => $estoque,

            'subtotal' => $subtotal

        );

    }


    mysqli_stmt_close($stmt);

}


/* =========================
   QUANTIDADE NO CARRINHO
   ========================= */

$quantidadeCarrinho =
    array_sum($_SESSION['carrinho']);


/* =========================
   DADOS DO USUÁRIO
   ========================= */

$nomeFarmacia =
    $_SESSION['farmacia_nome'] ?? 'Farmacia';

$nomeUsuario =
    $_SESSION['usuario_nome'] ?? '';

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        FarmaCerta - Carrinho
    </title>


    <link
        rel="stylesheet"
        href="../style.css"
    >


    <link
        rel="icon"
        type="image/png"
        href="../assets/LOGO_2.png"
    >


    <style>

        /* =========================
           LOGO CLICÁVEL
           ========================= */

        .logo-link {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: inherit;
        }

        .logo-link img {
            display: block;
        }

        .logo-link:hover {
            text-decoration: none;
        }

    </style>

</head>


<body>


    <!-- =========================
         CABEÇALHO
         ========================= -->

    <header class="topo">


        <!-- LOGO CLICÁVEL -->

        <a
            href="iniciobalconista.php"
            class="logo-link"
            title="Ir para o início"
        >

            <img
                src="../assets/LOGO_1.png"
                alt="FarmaCerta"
                width="200"
                height="auto"
            >

        </a>


        <h1>
            Sistema de Gestão
        </h1>


        <div class="usuario-topo">

            <span>

                <?php

                echo htmlspecialchars(
                    $nomeFarmacia,
                    ENT_QUOTES,
                    'UTF-8'
                );

                ?>

                — Balconista:

                <strong>

                    <?php

                    echo htmlspecialchars(
                        $nomeUsuario,
                        ENT_QUOTES,
                        'UTF-8'
                    );

                    ?>

                </strong>

            </span>


            <a
                class="logout"
                href="../logout.php"
            >
                SAIR
            </a>

        </div>

    </header>


    <!-- =========================
         MENU
         ========================= -->

    <nav class="menu">


        <a href="iniciobalconista.php">
            INÍCIO
        </a>


        <a href="produtosbalconista.php">
            PRODUTOS
        </a>


        <a
            href="carrinhobalconista.php"
            class="ativo"
        >

            CARRINHO
            (<?php echo $quantidadeCarrinho; ?>)

        </a>


        <a href="historicorecibobalconista.php">
            HISTÓRICO
        </a>


    </nav>


    <!-- =========================
         CONTEÚDO
         ========================= -->

    <main class="container">


        <div class="card">


            <h2>
                CARRINHO
            </h2>


            <!-- =========================
                 ERRO
                 ========================= -->

            <?php if (isset($_GET['erro'])) { ?>

                <p>

                    <?php

                    echo htmlspecialchars(
                        $_GET['erro'],
                        ENT_QUOTES,
                        'UTF-8'
                    );

                    ?>

                </p>

            <?php } ?>


            <!-- =========================
                 TABELA
                 ========================= -->

            <table class="tabela">


                <tr>

                    <th>
                        Produto
                    </th>

                    <th>
                        Quantidade
                    </th>

                    <th>
                        Valor unitário
                    </th>

                    <th>
                        Subtotal
                    </th>

                    <th>
                        Ação
                    </th>

                </tr>


                <?php if (count($produtosCarrinho) > 0) { ?>


                    <?php foreach ($produtosCarrinho as $produto) { ?>


                        <tr>


                            <!-- PRODUTO -->

                            <td>

                                <?php

                                echo htmlspecialchars(
                                    $produto['nome'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                );

                                ?>

                            </td>


                            <!-- QUANTIDADE -->

                            <td>

                                <form
                                    action="atualizarcarrinho.php"
                                    method="POST"
                                >


                                    <input
                                        type="hidden"
                                        name="produto_id"
                                        value="<?php echo (int) $produto['id']; ?>"
                                    >


                                    <input
                                        type="number"
                                        name="quantidade"
                                        value="<?php echo (int) $produto['quantidade']; ?>"
                                        min="1"
                                        max="<?php echo (int) $produto['estoque']; ?>"
                                        required
                                    >


                                    <button
                                        type="submit"
                                    >
                                        ATUALIZAR
                                    </button>


                                </form>

                            </td>


                            <!-- VALOR UNITÁRIO -->

                            <td>

                                R$

                                <?php

                                echo number_format(
                                    (float) $produto['preco'],
                                    2,
                                    ',',
                                    '.'
                                );

                                ?>

                            </td>


                            <!-- SUBTOTAL -->

                            <td>

                                R$

                                <?php

                                echo number_format(
                                    (float) $produto['subtotal'],
                                    2,
                                    ',',
                                    '.'
                                );

                                ?>

                            </td>


                            <!-- REMOVER -->

                            <td>


                                <form
                                    action="removercarrinho.php"
                                    method="POST"
                                >


                                    <input
                                        type="hidden"
                                        name="produto_id"
                                        value="<?php echo (int) $produto['id']; ?>"
                                    >


                                    <button
                                        class="acao excluir"
                                        type="submit"
                                    >
                                        REMOVER
                                    </button>


                                </form>


                            </td>


                        </tr>


                    <?php } ?>


                <?php } else { ?>


                    <tr>

                        <td colspan="5">
                            O carrinho está vazio.
                        </td>

                    </tr>


                <?php } ?>


            </table>


            <!-- =========================
                 TOTAL
                 ========================= -->

            <div
                class="total"
                style="color: white;"
            >

                VALOR TOTAL DA VENDA:

                R$

                <?php

                echo number_format(
                    $total,
                    2,
                    ',',
                    '.'
                );

                ?>

            </div>


            <!-- =========================
                 FINALIZAR VENDA
                 ========================= -->

            <?php if (count($produtosCarrinho) > 0) { ?>


                <form
                    method="POST"
                    action="finalizarvenda.php"
                    class="dados-pagamento"
                    style="margin-top: 24px;"
                >


                    <!-- CLIENTE -->

                    <label for="nome-cliente">
                        Nome do cliente
                    </label>


                    <input
                        id="nome-cliente"
                        name="nome_cliente"
                        type="text"
                        placeholder="Nome da pessoa que comprou"
                    >


                    <!-- CPF -->

                    <label for="cpf-cliente">
                        CPF do cliente (opcional)
                    </label>


                    <input
                        id="cpf-cliente"
                        name="cpf_cliente"
                        type="text"
                        maxlength="14"
                    >


                    <!-- PAGAMENTO -->

                    <label for="forma-pagamento">
                        Forma de pagamento
                    </label>


                    <select
                        id="forma-pagamento"
                        name="forma_pagamento"
                        onchange="mostrarValorRecebido()"
                        required
                    >

                        <option value="">
                            Selecione a forma de pagamento
                        </option>

                        <option value="dinheiro">
                            Dinheiro
                        </option>

                        <option value="pix">
                            Pix
                        </option>

                        <option value="debito">
                            Cartão de débito
                        </option>

                        <option value="credito">
                            Cartão de crédito
                        </option>

                    </select>


                    <!-- DINHEIRO -->

                    <div
                        id="campo-dinheiro"
                        style="display: none;"
                    >


                        <label for="valor-recebido">
                            Valor recebido
                        </label>


                        <input
                            id="valor-recebido"
                            name="valor_recebido"
                            type="number"
                            min="<?php echo number_format($total, 2, '.', ''); ?>"
                            step="0.01"
                            placeholder="R$ 0,00"
                            oninput="calcularTroco()"
                        >


                    </div>


                    <!-- RESUMO PAGAMENTO -->

                    <div
                        class="total"
                        style="color: white; margin-top: 18px;"
                    >

                        VALOR RECEBIDO:

                        R$

                        <span id="valor-mostrado">
                            0,00
                        </span>


                        <br>


                        TROCO:

                        R$

                        <span id="troco-mostrado">
                            0,00
                        </span>

                    </div>


                    <br>


                    <button
                        class="botao"
                        type="submit"
                    >
                        FINALIZAR COMPRA
                    </button>


                </form>


            <?php } ?>


        </div>


    </main>


    <!-- =========================
         JAVASCRIPT
         ========================= -->

    <script>

        var total =
            <?php echo json_encode((float) $total); ?>;


        /* =========================
           MOSTRAR VALOR RECEBIDO
           ========================= */

        function mostrarValorRecebido() {

            var forma =
                document.getElementById(
                    "forma-pagamento"
                ).value;


            var campo =
                document.getElementById(
                    "campo-dinheiro"
                );


            var recebido =
                document.getElementById(
                    "valor-recebido"
                );


            if (forma == "dinheiro") {

                campo.style.display =
                    "block";


                recebido.required =
                    true;


                calcularTroco();


            } else {

                campo.style.display =
                    "none";


                recebido.required =
                    false;


                recebido.value =
                    "";


                if (forma == "") {

                    document.getElementById(
                        "valor-mostrado"
                    ).innerHTML =
                        "0,00";

                } else {

                    document.getElementById(
                        "valor-mostrado"
                    ).innerHTML =
                        total
                        .toFixed(2)
                        .replace(".", ",");

                }


                document.getElementById(
                    "troco-mostrado"
                ).innerHTML =
                    "0,00";

            }

        }


        /* =========================
           CALCULAR TROCO
           ========================= */

        function calcularTroco() {

            var recebido =
                parseFloat(
                    document.getElementById(
                        "valor-recebido"
                    ).value || 0
                );


            var troco =
                recebido - total;


            if (troco < 0) {
                troco = 0;
            }


            document.getElementById(
                "valor-mostrado"
            ).innerHTML =
                recebido
                .toFixed(2)
                .replace(".", ",");


            document.getElementById(
                "troco-mostrado"
            ).innerHTML =
                troco
                .toFixed(2)
                .replace(".", ",");

        }

    </script>


</body>

</html>


<?php

mysqli_close($conexao);

?>
